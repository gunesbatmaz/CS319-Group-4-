import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
public class Player extends ImageLoader {
	    private static BufferedImage image;
	    static int counter=0;
	    private int x;
	    private int y;
	    private int cur = this.y;
	    private int height;
	    public Player() {
	    	super(0,0);
	    }
	 
	    public Player(int x, int y) {	 
	        super(x,y);
	    }
	    
	    public Player(int x, int y, String file){
	    	super(x,y,file);
	        this.x = x;
	        this.y = y;
	        try {
	        	
	            image = ImageIO.read(new File(file));
	        }
	        catch (Exception e) { System.out.println(e); }

	 
	    }
	    public static void Timeclock(){
	        TimerTask timerTask = new TimerTask(){
	        	@Override
	        	public void run(){
	        		//System.out.println("TimerTask executing counter is: " + counter);
	                counter++;//increments the counter
	                if((counter%10000)%2==0){
	                	//changeImage("run.png");
	                	System.out.println("777 ");
	                	
	                }
	                	
	                else{
	                	System.out.println("888 ");
	                	//changeImage("runner.gif");	                	
	                }

	        	}
	        };
	        Timer timer = new Timer("MyTimer");//create a new Timer

	        timer.scheduleAtFixedRate(timerTask, 500, 1000);	    	
	    }

        
	    public static void changeImage(String file){
	        try {
	            image = ImageIO.read(new File(file));
	            //System.out.println("asdasdasdasd");
	        }
	        catch (Exception e) { System.out.println(e); }	    	
	    }
	    /**
	     * Method that draws the image onto the Graphics object passed
	     * @param window
	     */
	    public void draw(Graphics window) {
	    	super.draw(window);
	    }
	    public void draw(Graphics window,int jump) {
	    	//super.draw(window,x);
	    	height=image.getHeight();
	    	window.drawImage(image, getX(), getY(), image.getWidth(), image.getHeight(), null);
	    	jump(jump);
	    }
	    public void jump(int jump){
	    	//isMax=false;
	    	//System.out.println(this.y + " "+ cur);
	    	this.y -= jump;
	    }
	    public void setX(int x) {
	        super.setX(x);
	    	//this.x = x;
	    }
	    public int getX() {
	        return this.x;
	    }
	    public int getY() {
	        return this.y;
	    }
	    public int getImageWidth() {
	    	return super.getImageWidth();
	        //return image.getWidth();
	    }
	 
	    public String toString() { 
	        return "Player: x=&amp;amp;amp;quot;" + getX() + ", y=" + getY() + ", height=" + image.getHeight() + ", width=" + image.getWidth();
	    }

		public int getImageHeight() {
			// TODO Auto-generated method stub
			return super.getImageHeight();
		} 
	
}
