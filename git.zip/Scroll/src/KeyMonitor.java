import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class KeyMonitor implements KeyListener {
	boolean jumped=false;
//    int PlayerOneY=275;
//    int PlayerTwoY=275;
    boolean wPressed;
    boolean sPressed;
    static boolean upPressed;
    boolean downPressed;
    public KeyMonitor () {
    }
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode()==KeyEvent.VK_UP)
				upPressed=true;
				jumped=true;
			System.out.println("keyPressed="+KeyEvent.getKeyText(e.getKeyCode()));
		}

		@Override
		public void keyReleased(KeyEvent e) {
			if(e.getKeyCode()==KeyEvent.VK_UP)
				jumped=false;
			upPressed=false;
			System.out.println("keyReleased="+KeyEvent.getKeyText(e.getKeyCode()));
		}
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}
	}