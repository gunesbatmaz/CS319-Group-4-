import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;


public class ScrollingBackground extends Canvas implements Runnable  {
 
	//private static KeyMonitor blocks;
	// Two copies of the background image to scroll
	//private boolean jumpFlag=AwtListenerDemo.jumpFlag;
    private Background backOne;
    private Background backTwo;
    private static Player player;
    private Player player2;
    private Hurdle hurdle1;
    private Hurdle hurdle2;
    private int maxJump;
    private BufferedImage back;
	private volatile static boolean isRunning = true;
    //private boolean upPressed=KeyMonitor.upPressed;
 
    public ScrollingBackground() {
//	    URL url = new URL("runner.gif");
//        Icon icon = new ImageIcon(url);
//        JLabel label = new JLabel(icon);
//        backOne = new Background();
//        backTwo = new Background(backOne.getImageWidth(), 0);

        backOne = new Background(0,0,"background.png");
        backTwo = new Background(backOne.getImageWidth(),0 ,"background.png");
        player= new Player(100,301,"run.png");
        //player2 = new Player(100,280,"run2.png");
        hurdle1 = new Hurdle(400,380,"engel.png");
        hurdle2 = new Hurdle(1000,380,"su_engel.png");
        //final int cur = player.getY();
        setMax (player.getY()- player.getImageHeight());
        addKeyListener(new KeyMonitor());
  //      LifeLeft lleft = new LifeLeft();
 //       static final int maxJump= player.getY()- player.getImageHeight();
//		KeyListener listener = new KeyMonitor(jumpFlag, jumpFlag, jumpFlag, jumpFlag);
//		addKeyListener(listener);
		setFocusable(true);
		
        new Thread(this).start();
        setVisible(true);
    }
    public int getMax(){
    	return maxJump;
    }
    public void setMax(int maxJump){
    	this.maxJump=maxJump;
    } 
    
    @Override
    public void run() {
        try {
            while (isRunning) {
                Thread.currentThread().sleep(5);
                repaint();
            }
        }
        catch (Exception e) {}
    }
    public static void kill(){
    	isRunning = false;
    }
    @Override
    public void update(Graphics window) {
        paint(window);
    }
 
    public void paint(Graphics window) {
        Graphics2D twoD = (Graphics2D)window;
        
        if (back == null)
            back = (BufferedImage)(createImage(getWidth(), getHeight()));
 
        // Create a buffer to draw to
        Graphics buffer = back.createGraphics();
 
        // Put the two copies of the background image onto the buffer
        backOne.draw(buffer,1);
        backTwo.draw(buffer,1);
        hurdle1.draw(buffer,1);
        hurdle2.draw(buffer,1);
        //player.draw(buffer);
           // player2.draw(buffer);
        //Player.Timeclock();
        if(collision(hurdle1) || collision(hurdle2) ){
        	System.out.println("1................................");
        	//LifeLeft.setB(true);
        	LifeLeft.takeLife();
        	LifeLeft.setB(false);
        }

        else{
        	LifeLeft.setB(true);
	        if( (player.getY()==351) && KeyMonitor.upPressed){ //up
	        	System.out.println("1 "+player.getY());
	        	while(player.getY()!=100){
	        		player.draw(buffer,1);
	        	}	        	
	        }
	
	//        else if(collision(hurdle2)){  //collision(hurdle2)
	//        	//System.out.println("2"); 
	//        	player.draw(buffer,1);
	//        }
	        else if(player.getY()<=350){					//falling
	        	player.draw(buffer,-1);
	        	//System.out.println("2 " + player.getY());  
	        }
	        	
	        else{
	        	//System.out.println("3 "+player.getY()); //on ground
	        	player.draw(buffer);
	        }
        }	
        // Draw the image onto the window
        twoD.drawImage(back, null, 0, 0);
 
    }
    
    public boolean collision (Hurdle h)
    {
        Rectangle r = new Rectangle(h.getX(),h.getY(),h.getImageWidth()/4,h.getImageHeight());
        Rectangle p = new Rectangle(player.getX(),player.getY(),player.getImageWidth()/4,player.getImageHeight()-10);

        // Assuming there is an intersect method, otherwise just handcompare the values
        if (r.intersects(p))
        {
           // A Collision!
           // we know which enemy (e), so we can call e.DoCollision();
           //System.out.println(h.getClass().getSimpleName()+" 1");
           return true;
        }
        else{
        	//System.out.println(h.getClass().getSimpleName()+" 0"); 
        	return false;
        }
    }
//    public void xOverlapCheck(Rectangle  black,Rectangle blue)
//    {
//        // black left side overlaps.
//        if ((black.topLeft.x <= blue.bottomRight.x) &&
//            (black.topLeft.x >= blue.topLeft.x))
//        {
//            return true;
//        }
//
//        // black right side overlaps.
//        if ((black.bottomRight.x <= blue.bottomRight.x) &&
//            (black.bottomRight.x >= blue.topLeft.x))
//        {
//            return true;
//        }
//
//        // black fully contains blue.
//        if ((black.bottomRight.x >= blue.bottomRight.x) &&
//            (black.topLeft.x <= blue.topLeft.x))
//        {
//            return true;
//        }
//    }
//	@Override
//	public void keyPressed(KeyEvent e) {
//		// TODO Auto-generated method stub
//		if(e.getKeyCode()==KeyEvent.VK_UP){
//			upPressed=true;
//			//jumped=true;
//		System.out.println("keyPressed="+KeyEvent.getKeyText(e.getKeyCode()));			
//		}
//
//		
//	}
//	@Override
//	public void keyReleased(KeyEvent e) {
//		// TODO Auto-generated method stub
//		if(e.getKeyCode()==KeyEvent.VK_UP){
//			upPressed=false;
//			System.out.println("keyReleased="+KeyEvent.getKeyText(e.getKeyCode()));			
//		}
//			//jumped=false;
//
//		
//	}
//	@Override
//	public void keyTyped(KeyEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
}