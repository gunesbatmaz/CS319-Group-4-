import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
 
public class Background extends ImageLoader{
	private BufferedImage image;
	 
    private int x;
    private int y;
 
    public Background() {
    	super(0,0);
    }
    public Background(int x, int y) {	 
      this.x = x;
      this.y = y;
      try {
          image = ImageIO.read(new File("background2.png"));
      }
      catch (Exception e) { System.out.println(e); }
    }  
    public Background(int x, int y, String file){
    	super(x,y,file);
        this.x = x;
        this.y = y;
        try {
            image = ImageIO.read(new File(file));
        }
        catch (Exception e) { System.out.println(e); }
    }
    public void draw(Graphics window) {
    	super.draw(window);
    }
    public void draw(Graphics window, int slideLeft) {
    	super.draw(window, slideLeft);
    	window.drawImage(image, getX(), getY(), image.getWidth(), image.getHeight(), null);
    	this.x -= slideLeft;
        if (this.x <= -1 * image.getWidth()) {
            this.x = this.x + image.getWidth() * 2;
        }
    }
    public void setX(int x) {
        super.setX(x);
    }
    public int getX() {
        return this.x;
    }
    public int getY() {
        return this.y;
    }
    public int getImageWidth() {
        return image.getWidth();
    }
    public String toString() { 
        return "Background: x=&amp;amp;amp;quot;" + getX() + ", y=" + getY() + ", height=" + image.getHeight() + ", width=" + image.getWidth();
    } 
}