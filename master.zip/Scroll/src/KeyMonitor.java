import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class KeyMonitor implements KeyListener {
	
	boolean jumped=false;
	boolean jumped2 = false;
    boolean wPressed;
    boolean sPressed;
    static boolean upPressed;
    static boolean spacePressed;
    boolean downPressed;
    public KeyMonitor () {
    }
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode()==KeyEvent.VK_UP)
				upPressed=true;
				jumped=true;
			if(e.getKeyCode()==KeyEvent.VK_SPACE)
				spacePressed = true;
				jumped = true;
			System.out.println("keyPressed="+KeyEvent.getKeyText(e.getKeyCode()));
		}

		@Override
		public void keyReleased(KeyEvent e) {
			if(e.getKeyCode()==KeyEvent.VK_UP)
				jumped=false;
				upPressed=false;
			if(e.getKeyCode()==KeyEvent.VK_SPACE)
				spacePressed = false;
				jumped = false;
			System.out.println("keyReleased="+KeyEvent.getKeyText(e.getKeyCode()));
		}
		@Override
		public void keyTyped(KeyEvent e) {			
		}
	}