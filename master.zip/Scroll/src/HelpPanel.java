import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class HelpPanel extends SideMenuPanel
{	
	private JTextArea helpText;
	private JLabel title;
	private ImageIcon help;

	public HelpPanel()
	{
		super();
		setLayout(null);
		setPreferredSize(new Dimension(960,640));
		setBackground(Color.BLACK);
		help = new ImageIcon("help.jpg");
	}
	public void paintComponent(Graphics page)
	{
		super.paintComponent(page);
		help.paintIcon(null,page,0,0);		
	}
}
