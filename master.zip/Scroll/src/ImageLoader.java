	import java.awt.Graphics;
	import java.awt.image.BufferedImage;
	import java.io.File;
	import javax.imageio.ImageIO;
 
public class ImageLoader {

    private BufferedImage image;
    private int x;
    private int y;
 
    public ImageLoader() {
        this(0,0);
    }
 
    public ImageLoader(int x, int y) {
        this.x = x;
        this.y = y;
    }  
    
    public ImageLoader(int x, int y, String file) {
        this.x = x;
        this.y = y;
 
        // Try to open the image file background.png
        try {
            image = ImageIO.read(new File(file));
        }
        catch (Exception e) { System.out.println(e); }
 
    } 
    public void draw(Graphics window) {
        window.drawImage(image, getX(), getY(), image.getWidth(), image.getHeight(), null);
    }
    public void draw(Graphics window, int slideLeft) {
        window.drawImage(image, getX(), getY(), image.getWidth(), image.getHeight(), null);
        this.x -= slideLeft;
        if (this.x <= -1 * image.getWidth()) {
            this.x = this.x + image.getWidth() * 2;
        }
    }
    public void draw(Graphics window, int x, int y) {
        window.drawImage(image, getX(), getY(), x, y, null);
        this.x -= 1;
        if (this.x <= -1 * image.getWidth()) {
            this.x = this.x + image.getWidth() * 2;
        }
    }   
    public void setY(int y) {
        this.y = y;
    }
    public void setX(int x) {
        this.x = x;
    }
    public int getX() {
        return this.x;
    }
    public int getY() {
        return this.y;
    }
    public int getImageWidth() {
        return image.getWidth();
    }
    public int getImageHeight() {
    	return image.getHeight();
    } 
    public String toString() { 
        return "Image: x=&amp;amp;amp;quot;" + getX() + ", y=" + getY() + ", height=" + image.getHeight() + ", width=" + image.getWidth();
    }
}