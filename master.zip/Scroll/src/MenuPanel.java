
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class MenuPanel extends JPanel
{
	private ImageIcon logo;
	public MenuPanel()
	{
		setLayout(null);
		setPreferredSize(new Dimension(960,640));
		setBackground(Color.BLACK);
		logo = new ImageIcon("logo.jpg");
	}
	public void paintComponent(Graphics page)
	{
		super.paintComponent(page);
		logo.paintIcon(null,page,0,0);		
	}
}
