
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class SideMenuPanel extends MenuPanel
{
	protected JButton backButton;
	
	public SideMenuPanel()
	{		
		super();
        backButton = new JButton("Back");
		backButton.setSize(new Dimension(157,45));
		backButton.setLocation(770,550);
		backButton.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 20));
		backButton.setForeground(Color.DARK_GRAY);
		backButton.setBackground(Color.WHITE);
        backButton.setFocusPainted(false);

		ButtonListener listener = new ButtonListener();
		backButton.addActionListener(listener);
		add(backButton);
	}	
	
	public void returnToMainMenu()
	{
		( ScreenView.getInstance() ).changeActivePanel( (ScreenView.getInstance()).getMain() );
	}	
	private class ButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			Object obj = event.getSource();
			
			try
    		{
    			if(obj == backButton)
				{
					returnToMainMenu();
				}	
    		}	
    		catch(Exception exc)
    		{    		
    			System.out.println("Exception is catched: " + exc.getMessage());//Show the message of exception
    		}										
		}						
	}
}