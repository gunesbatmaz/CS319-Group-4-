import java.awt.Component;
import javax.swing.JFrame;
 
public class RunGame extends JFrame {
 
    public RunGame() {
        super("Scrolling Background Demo");
        setSize(1024, 768);
 
        GameManager back = new GameManager();
        ((Component)back).setFocusable(true);
        getContentPane().add(back);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void newGame(){
    	new RunGame();
    }
}