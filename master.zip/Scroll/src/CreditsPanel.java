
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
public class CreditsPanel extends SideMenuPanel
{
	JTextArea creditsText;
	private JLabel title;
	public CreditsPanel()
	{
		super();
		creditsText = new JTextArea("\n  DEVELOPERS \n\n  Haluk �ncidelen \n\n  Ecem Afacan \n\n  Selim M�d�ko�lu");
		creditsText.setSize(new Dimension(205,250));
		creditsText.setLocation(435,275);
		creditsText.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.ITALIC, 20));
		creditsText.setLineWrap(true);
	    creditsText.setEditable(false);
	    creditsText.setVisible(true);	  
		creditsText.setForeground(Color.BLACK);
		add(creditsText);
	}	
}
