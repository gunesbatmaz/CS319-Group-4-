import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
public class Runner extends ImageLoader {
	    private static BufferedImage image;
	    static int counter=0;
	    private int x;
	    private int y;
	    private int cur = this.y;
	    private int height;
	    public Runner() {
	    	super(0,0);
	    }
	 
	    public Runner(int x, int y) {	 
	        super(x,y);
	    }
	    
	    public Runner(int x, int y, String file){
	    	super(x,y,file);
	        this.x = x;
	        this.y = y;
	        try {
	        	
	            image = ImageIO.read(new File(file));
	        }
	        catch (Exception e) { System.out.println(e); }	 
	    }
	    public static void Timeclock(){
	        TimerTask timerTask = new TimerTask(){
	        	@Override
	        	public void run(){
	                counter++;
	                if((counter%10000)%2==0){
	                	System.out.println("777 "); 	
	                }  	
	                else{
	                	System.out.println("888 ");                	
	                }
	        	}
	        };
	        Timer timer = new Timer("MyTimer");
	        timer.scheduleAtFixedRate(timerTask, 500, 1000);	    	
	    }
	    public static void changeImage(String file){
	        try {
	            image = ImageIO.read(new File(file));
	        }
	        catch (Exception e) { System.out.println(e); }	    	
	    }

	    public void draw(Graphics window) {
	    	super.draw(window);
	    }
	    public void draw(Graphics window,int jump) {
	    	height=image.getHeight();
	    	window.drawImage(image, getX(), getY(), image.getWidth(), image.getHeight(), null);
	    	jump(jump);
	    }
	    public void jump(int jump){
	    	this.y -= jump;
	    }
	    public void setX(int x) {
	        super.setX(x);
	    }
	    public int getX() {
	        return this.x;
	    }
	    public int getY() {
	        return this.y;
	    }
	    public int getImageWidth() {
	    	return super.getImageWidth();
	    }
	    public String toString() { 
	        return "Player: x=&amp;amp;amp;quot;" + getX() + ", y=" + getY() + ", height=" + image.getHeight() + ", width=" + image.getWidth();
	    }
		public int getImageHeight() {
			return super.getImageHeight();
		} 	
}