
public class LifeLeft {
	private static int lifeLeft=5;
	private static boolean b=false;
	
	public LifeLeft() {
		if(GameManager.multi()){
			lifeLeft = 10;
		}else
		lifeLeft=5;
	}
	public static int getLifeLeft() {
		return lifeLeft;
	}
	public static void setLifeLeft(int lifeLeft) {
		LifeLeft.lifeLeft = lifeLeft;
	}
	public static void takeLife(){
		if(getLifeLeft()==0){
			GameManager.kill();
		}
		if(isB())
			lifeLeft--;
		lifeLeftToString();
	}

	public static void lifeLeftToString(){
		System.out.println("Life Left= " + getLifeLeft());
	}
	public static boolean isB() {
		return b;
	}
	public static void setB(boolean b) {
		LifeLeft.b = b;
	}
	
}
