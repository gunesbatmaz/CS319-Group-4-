public class SystemInitiator 
{    
    public static void main(String[] args) 
    {
    	ScreenView screen = ScreenView.getInstance();
    }  
}