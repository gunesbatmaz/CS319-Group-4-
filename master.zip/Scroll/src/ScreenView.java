
import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.io.*;

public class ScreenView 
{
	private JFrame frame;
	private JPanel activePanel;
	private static ScreenView uniqueInstance = null;
	private MainMenuPanel mainP;
	private CreditsPanel  creditsP;
	private HelpPanel helpP;
	
	private ScreenView()
	{
		frame = new JFrame("Hurdle Race");
        frame.setSize(960,640);	
		frame.setResizable(false);
        frame.setVisible(true);			
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		mainP 	  = new MainMenuPanel();
		creditsP  = new CreditsPanel();
		helpP 	  = new HelpPanel();
		activePanel = mainP;		
    	frame.add(activePanel);
    	frame.pack();
	}
	public static ScreenView getInstance()
	{
		if(uniqueInstance == null)
			uniqueInstance = new ScreenView();
		return uniqueInstance;
	}
	public void changeActivePanel(JPanel panel)
	{
	    frame.getContentPane().removeAll();
	    frame.getContentPane().add(panel);
	    frame.getContentPane().revalidate();
	    frame.getContentPane().repaint();
	}	
	public JFrame getFrame()
	{
		return frame;
	}
	public JPanel newGame()
	{
		return new GameScreenPanel();
	}
	public JPanel getMain()
	{
		return mainP;
	}
	public JPanel getCredits()
	{
		return creditsP;
	}
	
	
//	public JPanel getSettings()
//	{
//		return settingsP;
//	}
	
	public JPanel getHelp()
	{
		return helpP;
	}
}
