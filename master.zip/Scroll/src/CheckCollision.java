
public class CheckCollision {

}
