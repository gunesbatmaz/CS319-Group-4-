import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;



public class GameManager extends Canvas implements Runnable  {
	private static int score=0;
    private Background backOne;
    private Background backTwo;
    private static Runner player;
    private Runner player_red;
    private Hurdle hurdle1;
    private Hurdle hurdle2,hurdle3,hurdle4;
    private int maxJump;
    private BufferedImage back;
	private volatile static boolean isRunning = true;
	private static boolean isMulti = false;
	
	
	public GameManager() {
		
		if(isMulti){
			backOne = new Background(0,0,"background.png");
	        backTwo = new Background(backOne.getImageWidth(),0 ,"background.png");
        	player_red = new Runner(100, 501, "run_red128.png");
        	hurdle3 = new Hurdle(400,550,"engel.png");
        	hurdle4 = new Hurdle(1000,550,"su_engel.png");
        	LifeLeft.setLifeLeft(10);
		}else{
			backOne = new Background(0,0,"arka1.png");
	        backTwo = new Background(backOne.getImageWidth(),0 ,"arka1.png");
		}
		
        player= new Runner(100,301,"run.png");
        hurdle1 = new Hurdle(400,380,"engel.png");
        hurdle2 = new Hurdle(1000,380,"su_engel.png");
        
        
        setMax (player.getY()- player.getImageHeight());
        addKeyListener(new KeyMonitor());

		setFocusable(true);
        new Thread(this).start();
        setVisible(true);
    }
    @Override
    public void run() {
        try {
            while (isRunning) {
                Thread.currentThread().sleep(5);
                repaint();
            }
        }
        catch (Exception e) {}
    }
    public static void kill(){
    	isRunning = false;    	
    }
    @Override
    public void update(Graphics window) {
        paint(window);
    }
    public static void startStop(){
    	System.out.println(GameManager.isRunning);
    	if(isRunning==false){
    		isRunning=true;
    	}    		
    	else
    		isRunning=false;
    }
    public void paint(Graphics window) {
        Graphics2D twoD = (Graphics2D)window;
        GameScreenPanel.drawScore(twoD);
        GameScreenPanel.drawLifeLeft(twoD);
        score++;
        if (back == null)
            back = (BufferedImage)(createImage(getWidth(), getHeight()));

        Graphics buffer = back.createGraphics();

        backOne.draw(buffer,1);
        backTwo.draw(buffer,1);
        hurdle1.draw(buffer,1);
        hurdle2.draw(buffer,1);
        if(isMulti){
        	hurdle3.draw(buffer,1);
        	hurdle4.draw(buffer,1);
        }
 
        if(collision(hurdle1, player) || collision(hurdle2, player) ){
        	System.out.println("1................................");
        	LifeLeft.takeLife();
        	LifeLeft.setB(false);
        }

        else{
        	LifeLeft.setB(true);
	        if( (player.getY()==351) && KeyMonitor.upPressed){ //up
	        	System.out.println("1 "+player.getY());
	        	while(player.getY()!=100){
	        		player.draw(buffer,1);
	        	}	        	
	        }	
	        else if(player.getY()<=350){					
	        	player.draw(buffer,-1);
	        }	        	
	        else{
	        	player.draw(buffer);
	        }
        }
        if(isMulti){
        	if(collision(hurdle3, player_red) || collision(hurdle4, player_red) ){
            	System.out.println("1................................");
            	LifeLeft.takeLife();
            	LifeLeft.setB(false);
            }

            else{
            	LifeLeft.setB(true);
    	        if( (player_red.getY()==551) && KeyMonitor.spacePressed){ //up
    	        	System.out.println("1 "+player_red.getY());
    	        	while(player_red.getY()!=200){
    	        		player_red.draw(buffer,1);
    	        	}	        	
    	        }	
    	        else if(player_red.getY()<=550){					
    	        	player_red.draw(buffer,-1);
    	        }	        	
    	        else{
    	        	player_red.draw(buffer);
    	        }
            }
        }

        twoD.drawImage(back, null, 0, 0);
    }   
    public static int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public boolean collision (Hurdle h, Runner player)
    {
        Rectangle r = new Rectangle(h.getX(),h.getY(),h.getImageWidth()/4,h.getImageHeight());
        Rectangle p = new Rectangle(player.getX(),player.getY(),player.getImageWidth()/4,player.getImageHeight()-10);
        
        if (r.intersects(p))
        {
           return true;
        }
        else{
        	return false;
        }
    }
	
	public static boolean multi() {
		return isMulti;
	}
	public static void setMulti(boolean b) {
		isMulti=b;
	}	
	
    public int getMax(){
    	return maxJump;
    }
    public void setMax(int maxJump){
    	this.maxJump=maxJump;
    } 
    

}