
import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;

import java.io.*;

public class GameScreenPanel extends JPanel
{
	public GameScreenPanel()
	{
		new RunGame();
		
	}

	public void paintComponent(Graphics page)
	{
		drawScore(page);
	}
    static void drawScore(Graphics g) {
  
        g.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN , 20));
        g.setColor(Color.GREEN);
        g.drawString("Score= " + GameManager.getScore(), 900, 20);

    }
    static void drawLifeLeft(Graphics g) {

        g.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN, 20));
        g.setColor(new Color(96, 128, 255));
        g.drawString("Life Left= " + LifeLeft.getLifeLeft(), 700, 20);

    }
	
}
