
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.io.*;

public class MainMenuPanel extends MenuPanel
{
	private JButton newGameButton;
	private JButton helpButton;
	private JButton optionsButton;
	private JButton MultiButton;
	private JButton creditsButton;
	private JButton exitButton;
	
	public MainMenuPanel()
	{
		super();

		newGameButton = new JButton("Single Player");
		newGameButton.setSize(new Dimension(157,45));
		newGameButton.setLocation(400,250);
		newGameButton.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 20));
		newGameButton.setForeground(Color.DARK_GRAY);
		newGameButton.setBackground(Color.WHITE);
        newGameButton.setFocusPainted(false);
        
        MultiButton = new JButton("Multiplayer");
		MultiButton.setSize(new Dimension(157,45));
		MultiButton.setLocation(400,300);
		MultiButton.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 20));
		MultiButton.setForeground(Color.DARK_GRAY);
		MultiButton.setBackground(Color.WHITE);
		MultiButton.setFocusPainted(false);
        
        helpButton = new JButton("Help");
		helpButton.setSize(new Dimension(157,45));
		helpButton.setLocation(400,350);
		helpButton.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 20));
		helpButton.setForeground(Color.DARK_GRAY);
		helpButton.setBackground(Color.WHITE);
        helpButton.setFocusPainted(false);
        
        optionsButton = new JButton("Options");
		optionsButton.setSize(new Dimension(157,45));
		optionsButton.setLocation(400,400);
		optionsButton.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 20));
		optionsButton.setForeground(Color.DARK_GRAY);
		optionsButton.setBackground(Color.WHITE);
        optionsButton.setFocusPainted(false);

        creditsButton = new JButton("Credits");
		creditsButton.setSize(new Dimension(157,45));
		creditsButton.setLocation(400,450);
		creditsButton.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 20));
		creditsButton.setForeground(Color.DARK_GRAY);
		creditsButton.setBackground(Color.WHITE);
        creditsButton.setFocusPainted(false);
        
        exitButton = new JButton("Exit");
		exitButton.setSize(new Dimension(157,45));
		exitButton.setLocation(400,500);
		exitButton.setFont(new Font("Adobe Caslon Pro Bold", Font.PLAIN + Font.BOLD, 20));
		exitButton.setForeground(Color.DARK_GRAY);
		exitButton.setBackground(Color.WHITE);
        exitButton.setFocusPainted(false);
        
		ButtonListener listener = new ButtonListener();
		newGameButton.addActionListener(listener);
		MultiButton.addActionListener(listener);
		helpButton.addActionListener(listener);
		optionsButton.addActionListener(listener);
		creditsButton.addActionListener(listener);
		exitButton.addActionListener(listener);

		add(newGameButton);
		add(MultiButton);
		add(helpButton);
		add(optionsButton);
		add(creditsButton);
		add(exitButton);
	}	

	private class ButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			Object obj = event.getSource();	
			try
    		{
    			if(obj == newGameButton)
				{
    				GameManager.setMulti(false);
					( ScreenView.getInstance() ).changeActivePanel( (ScreenView.getInstance()).newGame() );
				}
    			if(obj == MultiButton)
				{
    				GameManager.setMulti(true);
					( ScreenView.getInstance() ).changeActivePanel( (ScreenView.getInstance()).newGame() );
				}
				else if(obj == helpButton)
				{
					( ScreenView.getInstance() ).changeActivePanel( (ScreenView.getInstance()).getHelp() );
				}	
				else if(obj == creditsButton)
				{
					( ScreenView.getInstance() ).changeActivePanel( (ScreenView.getInstance()).getCredits() );	
				}	
				else if(obj == exitButton)
				{
					( ( ScreenView.getInstance() ).getFrame() ).dispose();
				}	
    		}	
    		catch(Exception exc)
    		{    		
    			System.out.println("Exception is catched: " + exc.getMessage());
    		}										
		}
						
	}
		
}
