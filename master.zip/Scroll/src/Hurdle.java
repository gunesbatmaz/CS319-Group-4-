import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Random;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.imageio.ImageIO;

public class Hurdle extends ImageLoader {
    private BufferedImage image ;

    private int x;
    private int y;
 
    public Hurdle() {
    	super(0,0);
    }
 
    public Hurdle(int x, int y) {	 
        super(x,y);
    }    
    public Hurdle(int x, int y, String file){
    	super(x,y,file);
        this.x = x;
        this.y = y;
        try {
            image = ImageIO.read(new File(file));
        }
        catch (Exception e) { System.out.println(e); }
    }

    public void draw(Graphics window) {
    	super.draw(window);
    }
    public void draw(Graphics window,int slideLeft) {
    	super.draw(window,x);
    	window.drawImage(image, getX(), getY(), image.getWidth(), image.getHeight(), null);
    	this.x -= slideLeft;
        if (this.x <= -1*image.getWidth()){
        	this.x = 1054;
        }
    }
    public int random(){
    	Random randomGenerator = new Random();
    	int randomInt = randomGenerator.nextInt(5);
    	return randomInt;
    }
    public void setX(int x) {
        super.setX(x);
    }
    public int getX() {
        return this.x;
    }
    public int getY() {
        return this.y;
    }
    public int getImageWidth() {
    	return super.getImageWidth();
    }
    public int getImageHeight() {
    	return image.getWidth();
    }
    public String toString() { 
        return "Hurdle: x=&amp;amp;amp;quot;" + getX() + ", y=" + getY() + ", height=" + image.getHeight() + ", width=" + image.getWidth();
    } 
}
